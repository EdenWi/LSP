import '../model/user_location.dart';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
// import 'daftar_lokasi_view.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../main.dart';

class HomeView extends StatefulWidget{
  @override
  State<StatefulWidget> createState(){
    return _HomeViewPageState();
  }
}

class _HomeViewPageState extends State<HomeView> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  final _nama = TextEditingController();
  final _keterangan = TextEditingController();
  final _kontributor = TextEditingController();

  bool boolKontributor = false;
  bool boolNama = false;
  bool boolKeterangan = false;
  bool _allSet = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldkey,
      body: _buildInputDataBody(context),
      bottomNavigationBar: _buildSaveButton(context),
    );
  }

  Widget _buildInputDataBody(BuildContext context) {
    var userLocation = Provider.of<UserLocation>(context);

    return Container(
      color: Colors.redAccent,
      padding: EdgeInsets.all(12.0),
      child: ListView(children: <Widget>[
        Text(
          "",
          textScaleFactor: 2.3,
          textAlign: TextAlign.center,
          style: TextStyle(
              fontWeight: FontWeight.w700, color: Colors.indigoAccent
          ),
        ),
        Image(
            image: AssetImage('assets/images/amru.png')
        ),
        SizedBox(height: 40),
        Container(
          width: 300,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20)),
          margin: EdgeInsets.only(top: 10),
          child: Material(
            elevation: 20.0,
            shadowColor: Colors.grey[200],
            borderRadius: BorderRadius.circular(20),
            child: TextFormField(
              keyboardType: TextInputType.text,
              autofocus: false,
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                  borderSide: BorderSide(
                    color: Colors.white38,
                  ),
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                  borderSide: BorderSide(
                    color: Colors.white,
                  ),
                ),
                labelText: 'Kontributor',
                fillColor: Colors.white,
                filled: true,
                contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
              ),
              onChanged: (value) {},
            ),
          ),
        ),
        Container(
          width: 300,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20)),
          margin: EdgeInsets.only(top: 10),
          child: Material(
            elevation: 20.0,
            shadowColor: Colors.grey[200],
            borderRadius: BorderRadius.circular(20),
            child: TextFormField(
              keyboardType: TextInputType.text,
              autofocus: false,
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                  borderSide: BorderSide(
                    color: Colors.white,
                  ),
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                  borderSide: BorderSide(
                    color: Colors.white,
                  ),
                ),
                labelText: 'Nama',
                fillColor: Colors.white,
                filled: true,
                contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
              ),
              onChanged: (value) {},
            ),
          ),
        ),
        Container(
          width: 300,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20)),
          margin: EdgeInsets.only(top: 10),
          child: Material(
            elevation: 20.0,
            shadowColor: Colors.grey[200],
            borderRadius: BorderRadius.circular(20),
            child: TextFormField(
              keyboardType: TextInputType.text,
              autofocus: false,
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                  borderSide: BorderSide(
                    color: Colors.white,
                  ),
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                  borderSide: BorderSide(
                    color: Colors.white,
                  ),
                ),
                labelText: 'Keterangan',
                fillColor: Colors.white54,
                filled: true,
                contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
              ),
              onChanged: (value) {},
            ),
          ),
        ),
        SizedBox(height: 20),
        Text(
          "Lokasi Anda Saat Ini:",
          textScaleFactor: 1.2,
          style: TextStyle(
              fontWeight: FontWeight.w700, color: Colors.yellow),
        ),
        SizedBox(width: 15),
        Text(
            "latitude \t\t\t\t: ${userLocation
                .latitude} \nLontitude \t: ${userLocation.longitude}",
            textScaleFactor: 1,
            style: TextStyle(color: Colors.blueAccent)
        ),
        // InkWell(
        //   onTap: (){
        //     Navigator.of(context).push(MaterialPageRoute(builder: (context){
        //       return DaftarLokasiPage();
        //     }));
        //   },
        //   child: ListTile(
        //     title: Text(
        //       "lihat daftar",
        //       textAlign: TextAlign.center,
        //       style:
        //       TextStyle(fontWeight: FontWeight.w700,color: Colors.red),
        //     ),
        //   ),
        // ),

      ],),
    );
  }

  Widget _buildSaveButton(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20), color: Colors.white),
      height: 50.0,
      child: MaterialButton(
        elevation: 20.0,
        minWidth: MediaQuery
            .of(context)
            .size
            .width,
        padding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
        onPressed: () {},
        child: Text(
          "Daftar",
          textScaleFactor: 1.5,
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}