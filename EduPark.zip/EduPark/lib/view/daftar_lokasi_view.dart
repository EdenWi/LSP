import 'dart:convert';
import '../model/daftar_lokasi.dart';
import '../main.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
// import 'detail_view.dart';

class DaftarLokasiPage extends StatefulWidget {
  @override
  _DaftarLokasiPageState createState() => _DaftarLokasiPageState();
}

class _DaftarLokasiPageState extends State<DaftarLokasiPage> {
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("Daftar Lokasi"),
      ),
      body: _DaftarLokasiPageBody(),
    );
  }
  Future<List<DaftarLokasi>> _parseLokasi() async {
    List<DaftarLokasi> daftarLokasi = [];

    var response = await http.post(Uri.parse(MyApp.URL));
    var response2 = await http.post(Uri.parse(MyApp.URL));

    var dataFromResponse = json.decode(response.body);

    dataFromResponse["data"].forEach((lokasiJSON) {
      DaftarLokasi itemLokasi = new DaftarLokasi(
        id: lokasiJSON["idx"].toString(),
        pengguna: lokasiJSON["pengguna"],
        namaLokasi: lokasiJSON["tempat"],
        keterangan: lokasiJSON["keterangan"],
        latitude: lokasiJSON["latitude"],
        longitude: lokasiJSON["longitude"],
      );
      daftarLokasi.add(itemLokasi);
    });
    print(daftarLokasi[0].pengguna);
    return daftarLokasi;
  }
  Widget _DaftarLokasiPageBody() {
    return FutureBuilder<List<DaftarLokasi>>(
      future: _parseLokasi(),
      builder: (context, snapshot) {
        return (snapshot.hasData)
            ? _buildLocationList(snapshot.data!)
            : Center(child: CircularProgressIndicator());
      },
    );
  }
  _buildLocationList(List<DaftarLokasi> listLokasi) {
    return ListView.builder(
        itemCount: listLokasi.length,
        itemBuilder: (context, index) {
          return InkWell(
            child:
            Card(
                child: Container(
                  padding: EdgeInsets.fromLTRB(5, 15, 5, 15),
                  width: double.infinity,
                  child:
                  Column(
                    children: [
                      Container(
                        child: Text(
                          listLokasi[index].keterangan,
                          textAlign: TextAlign.center,
                          textScaleFactor: 1.2,
                          style: TextStyle(color: Colors.blueGrey),
                        ),
                      ),
                      SizedBox(height: 10),
                      Container(
                        child: Row(children: <Widget>[
                          Expanded(
                            flex: 1,
                            child: Container(
                              padding: EdgeInsets.fromLTRB(15, 0, 0, 0),
                              child: Text(
                                listLokasi[index].pengguna,
                                textAlign: TextAlign.left,
                                textScaleFactor: 0.8,
                                style: TextStyle(color: Colors.blueGrey),
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Container(
                              padding: EdgeInsets.fromLTRB(0, 0, 15, 0),
                              child: Text(
                                listLokasi[index].latitude +
                                    ", " +
                                    listLokasi[index].longitude,
                                textAlign: TextAlign.right,
                                textScaleFactor: 0.8,
                                style: TextStyle(color: Colors.blueGrey),
                              ),
                            ),
                          ),
                        ]),
                      )
                    ],
                  ),
                )),

            onTap: () {
              // Navigator.push(
              //     context,
              //     MaterialPageRoute(
              //         builder: (context) => DetailView(
              //               daftarLokasi: listLokasi[index],
              //             )));
            },
          );
        });
  }
}