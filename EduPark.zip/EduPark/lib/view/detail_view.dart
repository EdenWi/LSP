import '../model/daftar_lokasi.dart';
import '../main.dart';
import 'daftar_lokasi_view.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class DetailView extends StatelessWidget {
  final DaftarLokasi daftarLokasi;

  DetailView({Key? key, required this.daftarLokasi}) : super(key: key);
  var _id = TextEditingController();
  var _kontributor = TextEditingController();
  var _namaLokasi = TextEditingController();
  var _keterangan = TextEditingController();

  @override
  Widget build(BuildContext context) {
    _id.text = daftarLokasi.id;
    _kontributor.text = daftarLokasi.pengguna;
    _namaLokasi.text = daftarLokasi.namaLokasi;
    _keterangan.text = daftarLokasi.keterangan;
    print("Lokasi_id=" + _id.text);
    return Scaffold(
        appBar: AppBar(
          title: Text('Update Data Lokasi'),
        ),
        body: Padding(
        padding: EdgeInsets.all(16.0),
    child: ListView(children: <Widget>[
    Text(
    "Update Data Lokasi",
    textScaleFactor: 2.3,
    textAlign: TextAlign.center,
    style: TextStyle(
    fontWeight: FontWeight.w700, color: Colors.indigoAccent),
    ),
    SizedBox(height: 40),
    TextField(
    controller: _kontributor,
    keyboardType: TextInputType.text,
    decoration: InputDecoration(
    labelText: "Nama Anda",
    //     errorText: boolKontributor ? "Nama diisi " : null,
    ),
    ),
    TextField(
    controller: _namaLokasi,
    keyboardType: TextInputType.text,
    decoration: InputDecoration(
    labelText: "Nama Lokasi",
    //    errorText: boolAlamat ? "Lokasi diisi " : null,
    ),
    ),
    TextField(
    controller: _keterangan,
    keyboardType: TextInputType.text,
    decoration: InputDecoration(
    labelText: "Keterangan Lokasi" + daftarLokasi.id,
    //      errorText: boolKeterangan ? "Keterangan diisi " : null,
    ),
    ),

    SizedBox(height: 20),
    Text(
    'Lokasi',
    textScaleFactor: 1.2,
    style: TextStyle(
    fontWeight: FontWeight.w700, color: Colors.blueAccent),
    ),
    SizedBox(width: 15), //spasi kosong
    Text(
    'Latitude \t\t\t\t: ${daftarLokasi.latitude} \nLongitude \t: ${daftarLokasi.longitude}',
    textScaleFactor: 1,
    style: TextStyle(color: Colors.blueAccent)),
    InkWell(
    onTap: () {
    Navigator.of(context).push(MaterialPageRoute(builder: (context) {
    return DaftarLokasiPage();
    }));
    },
    child: ListTile(
    title: Text(
    "Lihat Daftar",
    textAlign: TextAlign.center,
    style:
    TextStyle(fontWeight: FontWeight.w700, color: Colors.red),
    ),
    ),
    ),
    RaisedButton(
    onPressed: () {
    _saveData(
    daftarLokasi.id,
    _kontributor.text,
    _namaLokasi.text,
    _keterangan.text,
    daftarLokasi.longitude,
    daftarLokasi.latitude)
        .then((response) {
    return showDialog<void>(
    context: context,
    barrierDismissible: false, // user must tap button!
    builder: (BuildContext context) {
    return AlertDialog(
    title: Text('Keterangan!' + daftarLokasi.id),
    content: SingleChildScrollView(
    child: ListBody(
    children: <Widget>[
    Text('Data Berhasil Di Update.'),
    Text('Klik Tombol Ok untuk melihat hasil UPdate?'),
    ],
    ),
    ),
    actions: <Widget>[
    FlatButton(
    child: Text('Ok'),
    onPressed: () {
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (context) {
    return DaftarLokasiPage();
    }));
    },
    ),
    ],
    );
    },
    );
    });
    },
    child: Text(
    'Update Data',
    style: TextStyle(fontSize: 20),
    ),
    ),
    RaisedButton(
    child: Text(
    'Delete Data',
    style: TextStyle(fontSize: 20),
    ),
    onPressed: () {
    showDialog<void>(
    context: context,
    barrierDismissible: false, // user must tap button!
    builder: (BuildContext context) {
    return AlertDialog(
    title: Text('AlertDialog Title'),
    content: SingleChildScrollView(
    child: ListBody(
    children: <Widget>[
    Text('Anda akan menghapus data : ' +
    daftarLokasi.namaLokasi +
    '?\n'),
    Text(
    'Klik "OK" untuk melanjutkan atau "Cancel" untuk batal'),
    ],
    ),
    ),
    actions: <Widget>[
    FlatButton(
    child: Text('OK'),
    onPressed: () {
    _deleteData(daftarLokasi.id).then((response) {
    return showDialog<void>(
    context: context,
    barrierDismissible: false,
    // user must tap button!
    builder: (BuildContext context) {
    return AlertDialog(
    title: Text('Keterangan!'),
    content: SingleChildScrollView(
    child: ListBody(
    children: <Widget>[
    Text('Data Berhasil Di Hapus.'),
    Text(
    'Klik Tombol Ok untuk melihat hasil Penghapusan?'),
    ],
    ),
    ),
    actions: <Widget>[
    FlatButton(
    child: Text('Ok'),
    onPressed: () {
    Navigator.of(context).pop();
    Navigator.of(context).pop();
    Navigator.of(context).pop();
    },
    ),
    ],
    );
    },
    );
    });
    },
    ),
    FlatButton(
    onPressed: () {
    Navigator.of(context).pop();
    },
    child: Text("Cancel"))
    ],
    );
    },
    );
    },
    ),
    ]),
        ),
    );
  }

  Future<dynamic> _saveData(String id, String pengguna, String namaLokasi,
      String keterangan, String longitude, String latitude) async {
    //  var userLocation = Provider.of<UserLocation>(context);
    var response = await http.put(Uri.parse(MyApp.URL), body: {
      "idx": _id.text,
      "pengguna": pengguna,
      "tempat": namaLokasi,
      "keterangan": keterangan,
      "latitude": latitude,
      "longitude": longitude
    }).catchError((error) {
      print("Error insert user: $error");
    });
    return json.decode(response.body);
  }

  Future<dynamic> _deleteData(String id) async {
    print(id);
    final request = http.Request('DELETE', Uri.parse(MyApp.URL + "?idx=" + id));
    request.headers.addAll(
        <String, String>{"Content-Type": "application/x-www-form-urlencoded"});
    request.body = "idx=" + id;
    final response = await request.send();
    if (response.statusCode != 200) {
      return Future.error("error: Status Code ${response.statusCode}");
    }
    return await response.stream.bytesToString();
  }
}


