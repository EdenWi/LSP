import 'dart:async';
import '../model/user_location.dart';
import 'package:location/location.dart';


class LocationService {
  UserLocation? _currentLocation;

  var location = Location();

  StreamController<UserLocation> _locationController =
  StreamController<UserLocation>();

  Stream<UserLocation> get locationStream => _locationController.stream;

  LocationService() {
    location.requestPermission().then((granted) {
      if (granted == PermissionStatus.granted) {
        location.onLocationChanged.listen((dataLokasi) {
          if (dataLokasi != null) {
            _locationController.add(UserLocation(
              latitude: dataLokasi.latitude,
              longitude: dataLokasi.longitude,
            ));
            print(dataLokasi.isMock);
          }
        });
      }
    });
  }
  Future<UserLocation?> getLocation() async {
    try {
      var userLocation = await location.getLocation();
      _currentLocation = UserLocation(
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
      );
    } on Exception catch (e) {
      print('Gagal ambil lokasi: ${e.toString()}');
    }

    return _currentLocation;
  }
}
