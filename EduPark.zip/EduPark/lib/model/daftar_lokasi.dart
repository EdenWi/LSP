//tambahkan pada folder model, tambahkan file daftar_lokasi.dart
class DaftarLokasi {
  final String id;
  final String pengguna;
  final String namaLokasi;
  final String latitude;
  final String longitude;
  final String keterangan;

  DaftarLokasi({required this.id,required this.pengguna,required this.namaLokasi,required this.latitude,required this.longitude,required this.keterangan});
}
