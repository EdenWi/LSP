package com.example.lspuny

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
